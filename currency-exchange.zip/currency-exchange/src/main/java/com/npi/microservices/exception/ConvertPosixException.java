package com.npi.microservices.exception;

public class ConvertPosixException  extends Exception{
    public ConvertPosixException(String message) {
        super(message);
    }
}
